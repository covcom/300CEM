Squash
======

Ghosting
------
Android application that can be used for ghosting-sessions on a squash court. The user can specify times per corner, which
corners should be randomly hit, and more.

Simulation
------
Android application that tries to simulate the physical environment on a squash court.

Simulation Test
------
Test-project for the simulation application.


Contact: mystyfly@gmail.com

