package ch.squash.simulation.graphic;

public enum ShaderType {
	NO_LIGHT, LIGHT, POINT, 
}
