package ch.squash.simulation.shapes.common;

public enum SolidType {
	NONE, SPHERE, AREA, OTHER
};
